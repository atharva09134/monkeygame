
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var ground;


function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
 
  
   monkey = createSprite(30,180,400,20);
  monkey.addAnimation("monkey",monkey_running);
  monkey.scale = 0.1;  

   ground = createSprite(20,215,400,10);
     ground.x = ground.width /2;

    

  
  
  
  
  
   obstacle = createSprite(300,180,400,20);
  obstacle.addImage("obstacle",obstaceImage);
  obstacle.scale = 0.1;  

  
}


function draw() {
     background("white");
  
  ground.velocityX = -3 

    if (ground.x < 0){
      ground.x = ground.width/2;
    }
  
  
  
    drawSprites();
}






